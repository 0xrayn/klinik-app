import defaultTheme from 'tailwindcss/defaultTheme';
import forms from '@tailwindcss/forms';

/** @type {import('tailwindcss').Config} */
export default {
    content: [
        './resources/views/**/*.blade.php',
        './resources/js/**/*.{js,jsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                sans: ['Inter', ...defaultTheme.fontFamily.sans],
            },
            colors: {
                brand: {
                    50:  '#edfff9',
                    100: '#d5fff2',
                    200: '#adfee6',
                    300: '#70fbd4',
                    400: '#2cf0bb',
                    500: '#00d49e',
                    600: '#00ac81',
                    700: '#008a6a',
                    800: '#006d55',
                    900: '#005947',
                    950: '#00352b',
                },
                slate: {
                    50:  '#f8fafc',
                    100: '#f1f5f9',
                    200: '#e2e8f0',
                    300: '#cbd5e1',
                    400: '#94a3b8',
                    500: '#64748b',
                    600: '#475569',
                    700: '#334155',
                    800: '#1e293b',
                    900: '#0f172a',
                    950: '#020617',
                },
                violet: {
                    50:  '#f5f3ff',
                    500: '#8b5cf6',
                    600: '#7c3aed',
                    100: '#ede9fe',
                    700: '#6d28d9',
                },
                rose: {
                    50:  '#fff1f2',
                    100: '#ffe4e6',
                    500: '#f43f5e',
                    600: '#e11d48',
                },
                amber: {
                    50:  '#fffbeb',
                    100: '#fef3c7',
                    500: '#f59e0b',
                    600: '#d97706',
                },
                sky: {
                    50:  '#f0f9ff',
                    100: '#e0f2fe',
                    500: '#0ea5e9',
                    600: '#0284c7',
                },
            },
            borderRadius: {
                'xl':  '0.75rem',
                '2xl': '1rem',
                '3xl': '1.5rem',
            },
            boxShadow: {
                'card':    '0 1px 3px 0 rgb(0 0 0 / 0.04), 0 1px 2px -1px rgb(0 0 0 / 0.04)',
                'card-md': '0 4px 6px -1px rgb(0 0 0 / 0.07), 0 2px 4px -2px rgb(0 0 0 / 0.07)',
                'card-lg': '0 10px 15px -3px rgb(0 0 0 / 0.08), 0 4px 6px -4px rgb(0 0 0 / 0.08)',
                'brand':   '0 4px 14px 0 rgb(0 172 129 / 0.35)',
                'modal':   '0 20px 60px -15px rgb(0 0 0 / 0.3)',
                'inner':   'inset 0 2px 4px 0 rgb(0 0 0 / 0.05)',
            },
            animation: {
                'fade-in':   'fadeIn 0.2s ease-out',
                'slide-up':  'slideUp 0.3s ease-out',
                'scale-in':  'scaleIn 0.15s ease-out',
                'spin-slow': 'spin 2s linear infinite',
                'pulse-dot': 'pulseDot 1.5s ease-in-out infinite',
            },
            keyframes: {
                fadeIn:   { from: { opacity: 0 }, to: { opacity: 1 } },
                slideUp:  { from: { opacity: 0, transform: 'translateY(12px)' }, to: { opacity: 1, transform: 'translateY(0)' } },
                scaleIn:  { from: { opacity: 0, transform: 'scale(0.96)' }, to: { opacity: 1, transform: 'scale(1)' } },
                pulseDot: { '0%,100%': { transform: 'scale(1)', opacity: 1 }, '50%': { transform: 'scale(1.4)', opacity: 0.6 } },
            },
        },
    },
    plugins: [forms({ strategy: 'class' })],
};
